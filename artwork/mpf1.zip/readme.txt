Original image by Lee Davison.
http://members.lycos.co.uk/leeedavison/z80/mpf1/mpf_board.jpg
